const {
  useEffect,
  useMemo,
  useRef,
  useState
} = React;
const TABS = [{
  id: 'home',
  icon: '🏠',
  label: 'Trang chủ'
}, {
  id: 'horoscope',
  icon: '🔮',
  label: 'Tử vi'
}, {
  id: 'palm',
  icon: '✋',
  label: 'Chỉ tay'
}, {
  id: 'face',
  icon: '🙂',
  label: 'Xem tướng'
}, {
  id: 'astrology',
  icon: '🪐',
  label: 'Chiêm tinh'
}, {
  id: 'love',
  icon: '💞',
  label: 'Tình duyên'
}, {
  id: 'numerology',
  icon: '🔢',
  label: 'Thần số học'
}, {
  id: 'chat',
  icon: '🤖',
  label: 'AI Chat'
}, {
  id: 'multi',
  icon: '🧠',
  label: 'Multi AI'
}, {
  id: 'fengshui',
  icon: '☯️',
  label: 'Phong thủy'
}, {
  id: 'tarot',
  icon: '🃏',
  label: 'Bói bài'
}, {
  id: 'settings',
  icon: '⚙️',
  label: 'AI Keys'
}];
const DEFAULT_MESSAGES = [{
  role: 'assistant',
  text: 'Chào Đặng Năm. Mình là Đặng Năm AI Ultra. Bạn có thể hỏi về tử vi, thời tiết, ý tưởng, phân tích lỗi, viết nội dung hoặc code; mình sẽ trả lời rõ ràng và thực tế.'
}];
function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const value = JSON.parse(raw);
    return value ?? fallback;
  } catch {
    return fallback;
  }
}
function authHeaders() {
  const token = localStorage.getItem('synam_token') || '';
  return token ? {
    Authorization: `Bearer ${token}`
  } : {};
}
async function apiJSON(url, payload, method = 'POST') {
  const response = await fetch(url, {
    method,
    headers: {
      ...(method === 'GET' ? {} : {
        'Content-Type': 'application/json'
      }),
      ...authHeaders()
    },
    body: method === 'GET' ? undefined : JSON.stringify(payload || {})
  });
  const raw = await response.text();
  let data = {};
  try {
    data = raw ? JSON.parse(raw) : {};
  } catch {
    data = {
      message: raw
    };
  }
  if (!response.ok) throw new Error(data.error || data.message || `HTTP ${response.status}`);
  return data;
}
function optimizeImage(file, maxEdge = 1600, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('Chưa chọn ảnh.'));
    if (!String(file.type || '').startsWith('image/')) return reject(new Error('File phải là ảnh.'));
    if (file.size > 15 * 1024 * 1024) return reject(new Error('Ảnh quá lớn. Hãy chọn ảnh dưới 15 MB.'));
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Không đọc được ảnh.'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('Ảnh không hợp lệ hoặc định dạng chưa được trình duyệt hỗ trợ.'));
      image.onload = () => {
        const scale = Math.min(1, maxEdge / Math.max(image.width, image.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
function markdownLite(text = '') {
  const safe = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return safe.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>').replace(/^### (.*)$/gm, '<h3>$1</h3>').replace(/^## (.*)$/gm, '<h2>$1</h2>').replace(/^# (.*)$/gm, '<h1>$1</h1>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/^[-•] (.*)$/gm, '<li>$1</li>').replace(/\n/g, '<br>').replace(/(<li>.*?<\/li>)(<br>)?/gs, '<ul>$1</ul>').replace(/<\/ul><br><ul>/g, '');
}
function App() {
  const [tab, setTab] = useState('home');
  const [health, setHealth] = useState('Đang kiểm tra AI...');
  const [providers, setProviders] = useState([]);
  useEffect(() => {
    fetch('/api/health').then(r => r.json()).then(d => setHealth(d.ok ? 'Server online' : 'Server lỗi')).catch(() => setHealth('Server chưa kết nối'));
    loadProviders();
  }, []);
  async function loadProviders() {
    try {
      const data = await fetch('/api/ai/providers', {
        headers: authHeaders()
      }).then(r => r.json());
      setProviders(data.providers || []);
    } catch {
      setProviders([]);
    }
  }
  return React.createElement("main", {
    className: "app-shell"
  }, React.createElement(Hero, {
    tab: tab,
    setTab: setTab,
    health: health,
    providers: providers
  }), React.createElement(TabRail, {
    tab: tab,
    setTab: setTab
  }), React.createElement("section", {
    className: "workspace"
  }, tab === 'home' && React.createElement(Home, {
    setTab: setTab,
    providers: providers
  }), tab === 'chat' && React.createElement(Chat, {
    providers: providers
  }), tab === 'palm' && React.createElement(VisionTool, {
    mode: "palm",
    title: "Xem ch\u1EC9 tay AI",
    icon: "\u270B"
  }), tab === 'face' && React.createElement(VisionTool, {
    mode: "face",
    title: "Xem t\u01B0\u1EDBng AI",
    icon: "\uD83D\uDE42"
  }), tab === 'love' && React.createElement(LoveTool, null), tab === 'horoscope' && React.createElement(SimpleTool, {
    kind: "horoscope",
    title: "T\u1EED vi / Lu\u1EADn gi\u1EA3i",
    icon: "\uD83D\uDD2E",
    preset: "Lu\u1EADn t\u1EED vi h\xF4m nay, c\xF4ng vi\u1EC7c, t\xECnh c\u1EA3m, t\xE0i ch\xEDnh theo th\xF4ng tin sau:"
  }), tab === 'astrology' && React.createElement(AstrologyTool, null), tab === 'numerology' && React.createElement(NumerologyTool, null), tab === 'multi' && React.createElement(Chat, {
    providers: providers
  }), tab === 'fengshui' && React.createElement(FengShuiTool, null), tab === 'tarot' && React.createElement(TarotTool, null), tab === 'settings' && React.createElement(Settings, {
    providers: providers,
    reload: loadProviders
  })), React.createElement("nav", {
    className: "bottom-nav"
  }, TABS.map(t => React.createElement("button", {
    key: t.id,
    onClick: () => setTab(t.id),
    className: tab === t.id ? 'active' : ''
  }, React.createElement("span", null, t.icon), React.createElement("small", null, t.label)))));
}
function Hero({
  setTab,
  health,
  providers
}) {
  const configured = providers.filter(p => p.configured).length;
  return React.createElement("header", {
    className: "hero"
  }, React.createElement("div", {
    className: "hero-img hero-left"
  }, React.createElement("img", {
    src: "assets/hero-left.png",
    alt: "Minh h\u1ECDa S\u1EF9 N\u0103m b\xEAn tr\xE1i"
  })), React.createElement("div", {
    className: "hero-content"
  }, React.createElement("div", {
    className: "status-row"
  }, React.createElement("span", {
    className: "dot"
  }), health, React.createElement("span", {
    className: "chip"
  }, configured || 0, " AI \u0111ang b\u1EADt")), React.createElement("h1", null, "S\u1EF9 N\u0103m ", React.createElement("b", null, "Mystic")), React.createElement("p", null, "AI \u2022 T\u1EED vi \u2022 Ch\u1EC9 tay \u2022 Xem t\u01B0\u1EDBng \u2022 Chi\xEAm tinh"), React.createElement("div", {
    className: "hero-search"
  }, React.createElement("span", null, "\u2315"), React.createElement("input", {
    readOnly: true,
    value: "H\u1ECFi v\u1EC1 t\u1EED vi, ch\u1EC9 tay, t\u01B0\u1EDBng s\u1ED1, chi\xEAm tinh..."
  }), React.createElement("button", {
    onClick: () => setTab('chat')
  }, "\u2726 AI ph\xE2n t\xEDch")), React.createElement("div", {
    className: "hero-actions quick"
  }, React.createElement("button", {
    onClick: () => setTab('horoscope')
  }, "\uD83D\uDD2E T\u1EED vi h\xF4m nay"), React.createElement("button", {
    onClick: () => setTab('astrology')
  }, "\uD83E\uDE90 Cung ho\xE0ng \u0111\u1EA1o"), React.createElement("button", {
    onClick: () => setTab('palm')
  }, "\u270B Xem ch\u1EC9 tay"), React.createElement("button", {
    onClick: () => setTab('face')
  }, "\uD83D\uDE42 Xem t\u01B0\u1EDBng"), React.createElement("button", {
    onClick: () => setTab('tarot')
  }, "\uD83C\uDCCF \u0110\u1ED5i b\xE0i"))), React.createElement("div", {
    className: "hero-img hero-right"
  }, React.createElement("img", {
    src: "assets/hero-right.jpg",
    alt: "Minh h\u1ECDa S\u1EF9 N\u0103m b\xEAn ph\u1EA3i"
  })));
}
function TabRail({
  tab,
  setTab
}) {
  return React.createElement("nav", {
    className: "tab-rail"
  }, TABS.map(t => React.createElement("button", {
    key: t.id,
    className: tab === t.id ? 'active' : '',
    onClick: () => setTab(t.id)
  }, React.createElement("span", null, t.icon), t.label)));
}
function Home({
  setTab,
  providers
}) {
  const cards = [['🔮', 'Tử vi', 'Luận giải hôm nay, công việc, tình cảm, tài chính.', 'horoscope'], ['✋', 'Xem chỉ tay', 'Upload ảnh bàn tay để AI phân tích rõ hơn.', 'palm'], ['🙂', 'Xem tướng', 'Upload ảnh khuôn mặt, nhận luận giải nhẹ nhàng.', 'face'], ['🪐', 'Chiêm tinh', 'Cung hoàng đạo, vận trình tháng, tình cảm.', 'astrology'], ['💞', 'Tình duyên', 'Tính tuổi, ngũ hành, thần số học bằng code trước khi AI luận.', 'love'], ['🔢', 'Thần số học', 'Tính số chủ đạo, linh hồn, biểu đạt và luận AI.', 'numerology'], ['🤖', 'AI Chat Pro', 'Trả lời kiểu ChatGPT/Claude/Gemini, có nhớ ngữ cảnh, copy, thử lại.', 'chat'], ['🧠', 'Multi AI', 'Tự chọn Claude, Gemini, Groq, OpenRouter, ChatGPT, Grok.', 'multi'], ['☯️', 'Phong thủy', 'Màu hợp, hướng hợp, bố trí phòng/bàn làm việc.', 'fengshui'], ['🃏', 'Bói bài / Đổi bài', 'Bốc bài tham khảo và đổi bài nhanh.', 'tarot'], ['⚙️', 'AI Keys', 'Nhập key để bật Claude/Anthropic, Gemini, Groq...', 'settings']];
  return React.createElement("div", {
    className: "home-grid"
  }, React.createElement("section", {
    className: "premium-panel wide"
  }, React.createElement("h2", null, "\uD83D\uDCF1 M\xE0n h\xECnh ch\xEDnh mobile"), React.createElement("p", null, "Phi\xEAn b\u1EA3n hybrid NAM46 gi\u1EEF \u0111\u1EE7 c\xF4ng c\u1EE5 tr\xEAn \u0111i\u1EC7n tho\u1EA1i, \u0111\u1ED3ng b\u1ED9 chat v\u1EDBi server v\xE0 n\xE2ng c\u1EA5p tr\u1EE3 l\xFD AI v\u1EDBi ba m\u1EE9c \u0111\u1ED9 chi ti\u1EBFt chuy\xEAn nghi\u1EC7p."), React.createElement("div", {
    className: "provider-pills"
  }, providers.slice(0, 8).map(p => React.createElement("span", {
    className: p.configured ? 'on' : '',
    key: p.id
  }, p.configured ? '●' : '○', " ", p.label)))), cards.map(c => React.createElement("button", {
    key: c[3],
    className: "feature-card",
    onClick: () => setTab(c[3])
  }, React.createElement("b", null, c[0]), React.createElement("h3", null, c[1]), React.createElement("p", null, c[2]))));
}
function Chat({
  providers
}) {
  const [messages, setMessages] = useState(() => {
    const saved = readJSON('nam44_messages', DEFAULT_MESSAGES);
    return Array.isArray(saved) && saved.length ? saved.slice(-50) : DEFAULT_MESSAGES;
  });
  const [text, setText] = useState('');
  const [provider, setProvider] = useState('auto');
  const [answerStyle, setAnswerStyle] = useState('detailed');
  const [council, setCouncil] = useState(false);
  const [busy, setBusy] = useState(false);
  const [lastPrompt, setLastPrompt] = useState('');
  const boxRef = useRef(null);
  useEffect(() => {
    localStorage.setItem('nam44_messages', JSON.stringify(messages.slice(-50)));
    boxRef.current?.scrollTo({
      top: boxRef.current.scrollHeight,
      behavior: 'smooth'
    });
  }, [messages]);
  async function send(customText) {
    const content = (customText ?? text).trim();
    if (!content || busy) return;
    setText('');
    setLastPrompt(content);
    setBusy(true);
    const next = [...messages, {
      role: 'user',
      text: content
    }];
    setMessages([...next, {
      role: 'assistant',
      text: 'Đang suy nghĩ kỹ và kiểm tra ngữ cảnh…',
      loading: true
    }]);
    try {
      const data = await apiJSON('/api/multi-ai/chat', {
        message: content,
        history: next.slice(-20),
        provider,
        council,
        answerStyle
      });
      const answer = data.reply || data.text || 'AI chưa trả về nội dung.';
      setMessages([...next, {
        role: 'assistant',
        text: answer,
        meta: data.label || 'Đặng Năm AI'
      }]);
    } catch (e) {
      setMessages([...next, {
        role: 'assistant',
        text: `⚠️ ${e.message}\n\nGợi ý: vào tab AI Keys kiểm tra CLAUDE_API_KEY / ANTHROPIC_API_KEY / GEMINI_API_KEY hoặc chọn provider khác.`
      }]);
    } finally {
      setBusy(false);
    }
  }
  function copy(t) {
    navigator.clipboard?.writeText(t);
  }
  function speak(t) {
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(t);
      u.lang = 'vi-VN';
      speechSynthesis.speak(u);
    } catch {}
  }
  return React.createElement("section", {
    className: "chat-layout"
  }, React.createElement("aside", {
    className: "chat-side premium-panel"
  }, React.createElement("h2", null, "\uD83E\uDDE0 AI Router"), React.createElement("p", null, "Auto ch\u1ECDn provider c\xF3 key. \u01AFu ti\xEAn nhanh, ch\xEDnh x\xE1c, kh\xF4ng l\u1ED9 model."), React.createElement("select", {
    value: provider,
    onChange: e => setProvider(e.target.value)
  }, React.createElement("option", {
    value: "auto"
  }, "Auto Router"), providers.map(p => React.createElement("option", {
    key: p.id,
    value: p.id
  }, p.label))), React.createElement("select", {
    value: answerStyle,
    onChange: e => setAnswerStyle(e.target.value),
    "aria-label": "\u0110\u1ED9 chi ti\u1EBFt c\xE2u tr\u1EA3 l\u1EDDi"
  }, React.createElement("option", {
    value: "detailed"
  }, "Chi ti\u1EBFt chuy\xEAn nghi\u1EC7p"), React.createElement("option", {
    value: "expert"
  }, "Chuy\xEAn gia s\xE2u"), React.createElement("option", {
    value: "concise"
  }, "Ng\u1EAFn g\u1ECDn")), React.createElement("label", {
    className: "switch"
  }, React.createElement("input", {
    type: "checkbox",
    checked: council,
    onChange: e => setCouncil(e.target.checked)
  }), " H\u1ED9i \u0110\u1ED3ng AI"), React.createElement("button", {
    onClick: () => setMessages(DEFAULT_MESSAGES)
  }, "\uFF0B Chat m\u1EDBi"), React.createElement("div", {
    className: "mini-list"
  }, providers.map(p => React.createElement("span", {
    className: p.configured ? 'ok' : '',
    key: p.id
  }, p.configured ? '●' : '○', " ", p.label)))), React.createElement("div", {
    className: "chat-main premium-panel"
  }, React.createElement("div", {
    className: "chat-head"
  }, React.createElement("div", null, React.createElement("h2", null, "\uD83E\uDD16 AI Chat Ultra"), React.createElement("p", null, "Chat box hi\u1EC7n \u0111\u1EA1i, copy, \u0111\u1ECDc, th\u1EED l\u1EA1i, gi\u1EEF ng\u1EEF c\u1EA3nh.")), React.createElement("button", {
    onClick: () => speak(messages.filter(m => m.role === 'assistant').at(-1)?.text || '')
  }, "\uD83D\uDD0A \u0110\u1ECDc")), React.createElement("div", {
    className: "chat-box",
    ref: boxRef
  }, messages.map((m, i) => React.createElement("div", {
    key: i,
    className: `bubble ${m.role} ${m.loading ? 'loading' : ''}`
  }, React.createElement("div", {
    className: "avatar"
  }, m.role === 'user' ? '👤' : '✦'), React.createElement("div", {
    className: "bubble-body"
  }, React.createElement("div", {
    dangerouslySetInnerHTML: {
      __html: markdownLite(m.text)
    }
  }), m.role === 'assistant' && !m.loading && React.createElement("div", {
    className: "msg-actions"
  }, React.createElement("button", {
    onClick: () => copy(m.text)
  }, "Copy"), React.createElement("button", {
    onClick: () => speak(m.text)
  }, "\u0110\u1ECDc"), React.createElement("button", {
    onClick: () => send(lastPrompt)
  }, "Th\u1EED l\u1EA1i")))))), React.createElement("div", {
    className: "composer"
  }, React.createElement("textarea", {
    value: text,
    onChange: e => setText(e.target.value),
    onKeyDown: e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    },
    placeholder: "Nh\u1EAFn AI nh\u01B0 ChatGPT...",
    rows: "1"
  }), React.createElement("button", {
    disabled: busy,
    onClick: () => send()
  }, busy ? '…' : 'Gửi ✈'))));
}
function Settings({
  providers,
  reload
}) {
  const [keys, setKeys] = useState({});
  const [user, setUser] = useState(() => readJSON('synam_user', null));
  const [account, setAccount] = useState({
    name: user?.name || '',
    email: user?.email || '',
    password: ''
  });
  async function submitAccount(action) {
    try {
      const data = await apiJSON(`/api/auth/${action}`, account);
      localStorage.setItem('synam_user', JSON.stringify(data.user));
      localStorage.setItem('synam_token', data.token || '');
      setUser(data.user);
      setAccount({
        name: data.user.name || '',
        email: data.user.email || '',
        password: ''
      });
      alert(action === 'register' ? 'Đăng ký thành công.' : 'Đăng nhập thành công.');
      await reload();
    } catch (e) {
      alert(e.message);
    }
  }
  async function logout() {
    try {
      await apiJSON('/api/auth/logout', {});
    } catch {}
    localStorage.removeItem('synam_user');
    localStorage.removeItem('synam_token');
    setUser(null);
    setAccount({
      name: '',
      email: '',
      password: ''
    });
    await reload();
  }
  async function save() {
    try {
      await apiJSON('/api/ai/user-keys', {
        keys
      });
      await reload();
      alert('Đã lưu AI keys.');
    } catch (e) {
      alert(e.message);
    }
  }
  return React.createElement("section", {
    className: "premium-panel settings"
  }, React.createElement("h2", null, "\u2699\uFE0F Multi-AI API Keys"), React.createElement("p", null, "\u0110\u0103ng nh\u1EADp \u0111\u1EC3 l\u01B0u key c\xE1 nh\xE2n tr\xEAn server; n\u1EBFu ch\u01B0a \u0111\u0103ng nh\u1EADp, b\u1EA1n v\u1EABn c\xF3 th\u1EC3 d\xF9ng c\xE1c provider \u0111\xE3 c\u1EA5u h\xECnh trong m\xF4i tr\u01B0\u1EDDng ch\u1EA1y app."), React.createElement("div", {
    className: "account-card"
  }, React.createElement("h3", null, user ? `Đã đăng nhập: ${user.name || user.email}` : 'Tài khoản thành viên'), user ? React.createElement("button", {
    type: "button",
    onClick: logout
  }, "\u0110\u0103ng xu\u1EA5t") : React.createElement(React.Fragment, null, React.createElement("input", {
    value: account.name,
    onChange: e => setAccount(a => ({
      ...a,
      name: e.target.value
    })),
    placeholder: "T\xEAn hi\u1EC3n th\u1ECB"
  }), React.createElement("input", {
    value: account.email,
    onChange: e => setAccount(a => ({
      ...a,
      email: e.target.value
    })),
    type: "email",
    placeholder: "Email"
  }), React.createElement("input", {
    value: account.password,
    onChange: e => setAccount(a => ({
      ...a,
      password: e.target.value
    })),
    type: "password",
    placeholder: "M\u1EADt kh\u1EA9u t\u1EEB 6 k\xFD t\u1EF1"
  }), React.createElement("div", {
    className: "account-actions"
  }, React.createElement("button", {
    type: "button",
    onClick: () => submitAccount('login')
  }, "\u0110\u0103ng nh\u1EADp"), React.createElement("button", {
    type: "button",
    onClick: () => submitAccount('register')
  }, "\u0110\u0103ng k\xFD")))), React.createElement("div", {
    className: "key-grid"
  }, providers.map(p => React.createElement("label", {
    key: p.id
  }, React.createElement("span", null, p.label, " ", p.configured ? '✅' : '○'), React.createElement("input", {
    type: "password",
    placeholder: p.maskedKey || p.keyEnv || 'API key',
    onChange: e => setKeys(k => ({
      ...k,
      [p.id]: e.target.value
    }))
  }), React.createElement("small", null, p.model)))), React.createElement("button", {
    className: "primary",
    onClick: save
  }, "\uD83D\uDCBE L\u01B0u keys"));
}
function VisionTool({
  mode,
  title,
  icon
}) {
  const [result, setResult] = useState('Upload ảnh rồi bấm phân tích.');
  const [file, setFile] = useState(null);
  async function run() {
    if (!file) return setResult('Bạn cần chọn ảnh trước nhé.');
    setResult('Đang tối ưu ảnh và chuẩn bị phân tích...');
    try {
      const image = await optimizeImage(file);
      const payload = mode === 'palm' ? {
        mode,
        image,
        palmImage: image,
        palmLine: 'Tổng quan đường tay',
        palmNote: ''
      } : {
        mode,
        image,
        faceImage: image,
        facePart: 'Tổng quan ngũ quan',
        faceNote: ''
      };
      setResult('AI đang phân tích ảnh...');
      const d = await apiJSON('/api/vision-ai', payload);
      setResult(d.text || d.reply || 'Không có kết quả.');
    } catch (e) {
      setResult('⚠️ ' + e.message);
    }
  }
  return React.createElement("section", {
    className: "tool-grid"
  }, React.createElement("div", {
    className: "premium-panel"
  }, React.createElement("h2", null, icon, " ", title), React.createElement("input", {
    type: "file",
    accept: "image/*",
    onChange: e => setFile(e.target.files?.[0])
  }), React.createElement("button", {
    className: "primary",
    onClick: run
  }, "Ph\xE2n t\xEDch")), React.createElement(Result, {
    text: result
  }));
}
function LoveTool() {
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [out, setOut] = useState('Nhập thông tin hai người để luận giải.');
  async function run() {
    setOut('Đang tính bằng code và AI luận giải...');
    try {
      const d = await apiJSON('/api/love-ai', {
        persons: [{
          name: 'Người 1',
          birthDate: a
        }, {
          name: 'Người 2',
          birthDate: b
        }]
      });
      setOut(d.text || d.reply || 'Không có kết quả');
    } catch (e) {
      setOut('⚠️ ' + e.message);
    }
  }
  return React.createElement("section", {
    className: "tool-grid"
  }, React.createElement("div", {
    className: "premium-panel"
  }, React.createElement("h2", null, "\uD83D\uDC9E T\xECnh duy\xEAn"), React.createElement("input", {
    value: a,
    onChange: e => setA(e.target.value),
    placeholder: "Ng\xE0y sinh ng\u01B0\u1EDDi 1: 01/01/2000"
  }), React.createElement("input", {
    value: b,
    onChange: e => setB(e.target.value),
    placeholder: "Ng\xE0y sinh ng\u01B0\u1EDDi 2: 02/02/2004"
  }), React.createElement("button", {
    className: "primary",
    onClick: run
  }, "Lu\u1EADn gi\u1EA3i")), React.createElement(Result, {
    text: out
  }));
}
function SimpleTool({
  kind,
  title,
  icon,
  preset = '',
  placeholder = 'Bạn muốn hỏi điều gì?'
}) {
  const [q, setQ] = useState('');
  const [out, setOut] = useState('Nhập nội dung rồi bấm luận giải.');
  async function run() {
    setOut('AI đang luận giải...');
    try {
      const d = await apiJSON('/api/multi-ai/chat', {
        message: `${preset || title} ${q}`,
        provider: 'auto'
      });
      setOut(d.text || d.reply || 'Không có kết quả');
    } catch (e) {
      setOut('⚠️ ' + e.message);
    }
  }
  return React.createElement("section", {
    className: "tool-grid"
  }, React.createElement("div", {
    className: "premium-panel"
  }, React.createElement("h2", null, icon, " ", title), React.createElement("textarea", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: placeholder
  }), React.createElement("button", {
    className: "primary",
    onClick: run
  }, "Lu\u1EADn gi\u1EA3i")), React.createElement(Result, {
    text: out
  }));
}
function AstrologyTool() {
  return React.createElement(SimpleTool, {
    kind: "astrology",
    title: "Chi\xEAm tinh",
    icon: "\uD83E\uDE90",
    preset: "Lu\u1EADn chi\xEAm tinh theo cung ho\xE0ng \u0111\u1EA1o, th\u1EDDi \u0111i\u1EC3m hi\u1EC7n t\u1EA1i v\xE0 c\xE2u h\u1ECFi sau:",
    placeholder: "V\xED d\u1EE5: Song T\u1EED, t\xECnh duy\xEAn th\xE1ng n\xE0y th\u1EBF n\xE0o?"
  });
}
function FengShuiTool() {
  return React.createElement(SimpleTool, {
    kind: "fengshui",
    title: "Phong th\u1EE7y",
    icon: "\u262F\uFE0F",
    preset: "Ph\xE2n t\xEDch phong th\u1EE7y th\u1EF1c t\u1EBF, m\xE0u h\u1EE3p, h\u01B0\u1EDBng h\u1EE3p, b\u1ED1 tr\xED kh\xF4ng gian theo th\xF4ng tin sau:",
    placeholder: "V\xED d\u1EE5: sinh n\u0103m 1995, mu\u1ED1n xem h\u01B0\u1EDBng b\xE0n l\xE0m vi\u1EC7c v\xE0 m\xE0u h\u1EE3p."
  });
}
function TarotTool() {
  const cards = ['The Fool - Khởi đầu mới', 'The Magician - Chủ động tạo cơ hội', 'The High Priestess - Lắng nghe trực giác', 'The Lovers - Lựa chọn trong tình cảm', 'The Chariot - Tiến lên quyết đoán', 'Strength - Bình tĩnh và mềm mỏng', 'The Hermit - Cần thời gian suy ngẫm', 'Wheel of Fortune - Vận trình đang xoay chuyển', 'The Star - Hy vọng và chữa lành', 'The Sun - Rõ ràng, vui vẻ, tích cực'];
  const [q, setQ] = useState('');
  const [picked, setPicked] = useState([]);
  const [out, setOut] = useState('Nhập câu hỏi rồi bấm bốc bài. Có thể bấm Đổi bài để bốc lại.');
  async function draw() {
    const deck = [...cards].sort(() => Math.random() - .5).slice(0, 3);
    setPicked(deck);
    setOut('AI đang luận 3 lá bài...');
    try {
      const d = await apiJSON('/api/multi-ai/chat', {
        provider: 'auto',
        message: `Bói bài tarot tham khảo, không khẳng định tuyệt đối. Câu hỏi: ${q}. Ba lá: ${deck.join(', ')}. Hãy luận rõ: hiện tại, lời khuyên, kết quả gần.`
      });
      setOut(d.text || d.reply || deck.join('\n'));
    } catch (e) {
      setOut(`### 🃏 Ba lá bài\n- ${deck.join('\n- ')}\n\nLời khuyên: xem như tham khảo để bình tĩnh lựa chọn, không quyết định thay thực tế.`);
    }
  }
  return React.createElement("section", {
    className: "tool-grid"
  }, React.createElement("div", {
    className: "premium-panel"
  }, React.createElement("h2", null, "\uD83C\uDCCF B\xF3i b\xE0i / \u0110\u1ED5i b\xE0i"), React.createElement("textarea", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "B\u1EA1n mu\u1ED1n h\u1ECFi \u0111i\u1EC1u g\xEC?"
  }), React.createElement("button", {
    className: "primary",
    onClick: draw
  }, picked.length ? '🔄 Đổi bài' : '🃏 Bốc bài'), React.createElement("div", {
    className: "tarot-cards"
  }, picked.map(c => React.createElement("span", {
    key: c
  }, c)))), React.createElement(Result, {
    text: out
  }));
}
function NumerologyTool() {
  const [name, setName] = useState('');
  const [birth, setBirth] = useState('');
  const [out, setOut] = useState('Nhập họ tên và ngày sinh để tính thần số học.');
  function sumDigits(v) {
    let n = String(v).replace(/\D/g, '').split('').reduce((a, b) => a + Number(b), 0);
    while (n > 9 && ![11, 22, 33].includes(n)) n = String(n).split('').reduce((a, b) => a + Number(b), 0);
    return n || 0;
  }
  async function run() {
    const life = sumDigits(birth);
    setOut('Đang tính local và AI luận giải...');
    try {
      const d = await apiJSON('/api/multi-ai/chat', {
        provider: 'auto',
        message: `Thần số học cho tên ${name || 'chưa nhập'}, ngày sinh ${birth || 'chưa nhập'}, số chủ đạo local là ${life}. Luận rõ tính cách, tình duyên, công việc, lời khuyên.`
      });
      setOut(d.text || d.reply || `Số chủ đạo: ${life}`);
    } catch (e) {
      setOut(`### 🔢 Kết quả local
- Họ tên: ${name || 'Chưa nhập'}
- Ngày sinh: ${birth || 'Chưa nhập'}
- Số chủ đạo: ${life || 'Chưa đủ dữ liệu'}

Kết quả chỉ mang tính tham khảo.`);
    }
  }
  return React.createElement("section", {
    className: "tool-grid"
  }, React.createElement("div", {
    className: "premium-panel"
  }, React.createElement("h2", null, "\uD83D\uDD22 Th\u1EA7n s\u1ED1 h\u1ECDc AI"), React.createElement("input", {
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "H\u1ECD v\xE0 t\xEAn"
  }), React.createElement("input", {
    value: birth,
    onChange: e => setBirth(e.target.value),
    placeholder: "Ng\xE0y sinh: 01/01/2000"
  }), React.createElement("button", {
    className: "primary",
    onClick: run
  }, "\uD83E\uDD16 Lu\u1EADn th\u1EA7n s\u1ED1 h\u1ECDc")), React.createElement(Result, {
    text: out
  }));
}
function Result({
  text
}) {
  return React.createElement("article", {
    className: "premium-panel result"
  }, React.createElement("h2", null, "\uD83D\uDCCC K\u1EBFt qu\u1EA3"), React.createElement("div", {
    dangerouslySetInnerHTML: {
      __html: markdownLite(text)
    }
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App, null));
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('service-worker.js').catch(() => {}));
}
